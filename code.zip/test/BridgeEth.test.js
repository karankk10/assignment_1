// BridgeEth.test.js
const BridgeEth = artifacts.require("BridgeEth");
const TokenEth = artifacts.require("TokenEth");

contract("BridgeEth", (accounts) => {
    let bridgeEth;
    let tokenEth;

    before(async () => {
        tokenEth = await TokenEth.new({ from: accounts[0] });
        bridgeEth = await BridgeEth.new(tokenEth.address, { from: accounts[0] });
    });

    it("should allow deposits", async () => {
        const amount = web3.utils.toWei("1", "ether");
        await tokenEth.approve(bridgeEth.address, amount, { from: accounts[0] });
        await bridgeEth.deposit(amount, { from: accounts[0] });

        const balance = await tokenEth.balanceOf(bridgeEth.address);
        assert.equal(balance.toString(), amount, "Token balance in bridge is incorrect");
    });

    it("should allow withdrawals by the owner", async () => {
        const recipient = accounts[1];
        const amount = web3.utils.toWei("1", "ether");
        await bridgeEth.withdraw(amount, recipient, { from: accounts[0] });

        const balance = await tokenEth.balanceOf(recipient);
        assert.equal(balance.toString(), amount, "Recipient did not receive the tokens");
    });
});
